﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UniRx;
using UniRx.Triggers;

public class MapPointer : MonoBehaviour
{
    public IObservable<Vector3> OnClick;

    void Awake() {

        OnClick = this.UpdateAsObservable()
                      .Where(_ => Input.GetMouseButtonDown(0))
                      .Select(_ => Input.mousePosition);
    }

    void Update() {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit = new RaycastHit();
        Physics.Raycast(ray, out hit, 100);
        Debug.Log(hit.point);
    }

}
